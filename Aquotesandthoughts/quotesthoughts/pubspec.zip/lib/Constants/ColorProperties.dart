import 'package:flutter/material.dart';

const kPrimaryColor = Colors.teal;
final appColorOrange = Color(0xFFED5D2A);
final appAnotherColorBlue = Color(0xFF1DA3BF);
final appAnotherColorGreen = Color(0xFF17A398);