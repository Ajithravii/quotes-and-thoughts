package com.quotesthoughts;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
